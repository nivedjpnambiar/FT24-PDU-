/*
 * Current_Monitoring.c
 *
 *  Created on: 24. April, 2024
 *      Author: nived
 */

#include "Current_Monitoring.h"
#include "main.h"

volatile union adc1_channels {
  struct {
    uint16_t isense5;   // LiDAR | GSS  (DSEL7)
    uint16_t isense3;   // AlwaysOn | SDC  (DSEL4)
    uint16_t isense7;   // Misc | Inverters  (DSEL5)
    uint16_t isense9;   // DRS
    uint16_t isense12;  // ACU 
    uint16_t isense11;  // EPSC = ELIAS 
    uint16_t isense6;   // Radiator Fans
    uint16_t isense13;  // TSAC Fans
  } adcbank1;

  uint16_t adcbuffer[8]; // array 8*16 bit
 
} adc_channels1;
// ADC's anpassen adc1 - 9, adc2 ist halt 5 , buffer anpassen und namen auch ( isense usw)
volatile union adc2_channels {
  struct {
    uint16_t isense2;    // EBS A | EBS B  (DSEL3)
    uint16_t isense1;    // EBS CS
    uint16_t isense10;   // Hydraulic Aggregate 
    uint16_t isense4;    // Water Pump | Reserved  (DSEL8)
    uint16_t lv_sens;    // LV voltage
  } adcbank1;

  uint16_t adcbuffer[5];

} adc_channels2;

CurrentMeasurements current_measurements_adc_val;

GPIO_PinState adcbank1 = GPIO_PIN_RESET;
GPIO_PinState adcbank2 = GPIO_PIN_RESET;

ADC_HandleTypeDef* adc1;
ADC_HandleTypeDef* adc2;

void currentMonitor_init(ADC_HandleTypeDef* hadc1, ADC_HandleTypeDef* hadc2, // init ist initilisierung 
                         TIM_HandleTypeDef* trigtim) {
  HAL_GPIO_WritePin(DSEL_3_GPIO_Port, DSEL_3_Pin, adcbank2);
  HAL_GPIO_WritePin(DSEL_4_GPIO_Port, DSEL_4_Pin, adcbank1);
  HAL_GPIO_WritePin(DSEL_5_GPIO_Port, DSEL_5_Pin, adcbank1);
  HAL_GPIO_WritePin(DSEL_7_GPIO_Port, DSEL_7_Pin, adcbank1);
  HAL_GPIO_WritePin(DSEL_8_GPIO_Port, DSEL_8_Pin, adcbank2);
  adc1 = hadc1;
  adc2 = hadc2;
  HAL_TIM_Base_Start(trigtim);
  HAL_ADC_Start_DMA(hadc1, (uint32_t*)adc_channels1.adcbuffer, 8);
  HAL_ADC_Start_DMA(hadc2, (uint32_t*)adc_channels2.adcbuffer, 5); // wie adc mit dma geht , red mit jasper
}

uint8_t currentMonitor_checklimits() { return 0; }

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {

  if (hadc == adc1) {

    if (adcbank1 == GPIO_PIN_RESET) {

      current_measurements_adc_val.lidar      =
          adc_channels1.adcbank1.isense5 * CURR_SENSE_FACTOR_7_5A;
      current_measurements_adc_val.always_on  =
          adc_channels1.adcbank1.isense3 * CURR_SENSE_FACTOR_5A;
      current_measurements_adc_val.misc       =
          adc_channels1.adcbank1.isense7 * CURR_SENSE_FACTOR_7_5A; 
    
      adcbank1 = GPIO_PIN_SET;

    } else {

      current_measurements_adc_val.gss        =
          adc_channels1.adcbank1.isense5 * CURR_SENSE_FACTOR_7_5A;
      current_measurements_adc_val.sdc        =
          adc_channels1.adcbank1.isense3 * CURR_SENSE_FACTOR_5A;
      current_measurements_adc_val.inverters  =
          adc_channels1.adcbank1.isense7 * CURR_SENSE_FACTOR_7_5A; 

      adcbank1 = GPIO_PIN_RESET;

    }

    current_measurements_adc_val.servos         =
        adc_channels1.adcbank1.isense9  * CURR_SENSE_FACTOR_21A;
    current_measurements_adc_val.acu            =
        adc_channels1.adcbank1.isense12 * CURR_SENSE_FACTOR_31A;
    current_measurements_adc_val.epsc           =
        adc_channels1.adcbank1.isense11 * CURR_SENSE_FACTOR_21A;
    current_measurements_adc_val.radiator_fans  =
        adc_channels1.adcbank1.isense6  * CURR_SENSE_FACTOR_21A;
    current_measurements_adc_val.tsac_fans      =
        adc_channels1.adcbank1.isense13 * CURR_SENSE_FACTOR_31A;

    HAL_GPIO_WritePin(DSEL_4_GPIO_Port, DSEL_4_Pin, adcbank1); 
    HAL_GPIO_WritePin(DSEL_5_GPIO_Port, DSEL_5_Pin, adcbank1);                 
    HAL_GPIO_WritePin(DSEL_7_GPIO_Port, DSEL_7_Pin, adcbank1); 

  }
  else
  if (hadc == adc2) {

    if (adcbank2 == GPIO_PIN_RESET) {

      current_measurements_adc_val.ebsvalve_a   =
          adc_channels2.adcbank1.isense2 * CURR_SENSE_FACTOR_5A;
      current_measurements_adc_val.cooling_pump =
          adc_channels2.adcbank1.isense4 * CURR_SENSE_FACTOR_7_5A;

      adcbank2 = GPIO_PIN_SET;

    } else {

      current_measurements_adc_val.ebsvalve_b   =
          adc_channels2.adcbank1.isense2 * CURR_SENSE_FACTOR_5A;
      current_measurements_adc_val.reserved     =
          adc_channels2.adcbank1.isense4 * CURR_SENSE_FACTOR_7_5A;

      adcbank2 = GPIO_PIN_RESET;

    }

    current_measurements_adc_val.ebs_cs_valve =
        adc_channels2.adcbank1.isense1  * CURR_SENSE_FACTOR_5A;
    current_measurements_adc_val.aggregat     =
        adc_channels2.adcbank1.isense10 * CURR_SENSE_FACTOR_21A;
    current_measurements_adc_val.lv_v         =
        adc_channels2.adcbank1.lv_sens  * LV_SENSE_FACTOR;

    HAL_GPIO_WritePin(DSEL_3_GPIO_Port, DSEL_3_Pin, adcbank2);
    HAL_GPIO_WritePin(DSEL_8_GPIO_Port, DSEL_8_Pin, adcbank2);

  }

}