/*
 * Current_Monitoring.h
 *
 *  Created on: 24. April, 2024
 *      Author: nived
 */

#ifndef INC_CURRENT_MONITORING_H_
#define INC_CURRENT_MONITORING_H_

#include "stm32f3xx_hal.h"

// Convert ADC quants to V
#define ADC_V_FACTOR (3.3f / 4096)
// Scale to LV by divider to mV
#define LV_SENSE_FACTOR (1e3 * (ADC_V_FACTOR * ((27.f+8.2f)/8.2f)))

// Convert ADC quants to I_S in mA
#define CURR_SENSE_IS_FACTOR  (ADC_V_FACTOR / 1.2f) // 3.3V / 12bit / 1.2kOhm
// Convert ADC quants to I_L in mA
#define CURR_SENSE_FACTOR_5A  (3700 * CURR_SENSE_IS_FACTOR)
#define CURR_SENSE_FACTOR_7_5A (5450 * CURR_SENSE_IS_FACTOR)
#define CURR_SENSE_FACTOR_21A (22700 * CURR_SENSE_IS_FACTOR)
#define CURR_SENSE_FACTOR_31A (34100 * CURR_SENSE_IS_FACTOR)

typedef struct {
  uint16_t acu;
  uint16_t epsc;
  uint16_t radiator_fans;
  uint16_t tsac_fans;
  uint16_t gss;
  uint16_t lidar;
  uint16_t sdc;
  uint16_t inverters;
  uint16_t servos;
  uint16_t aggregat;
  uint16_t misc;
  uint16_t always_on;
  uint16_t ebs_cs_valve;
  uint16_t reserved;
  uint16_t ebsvalve_a;
  uint16_t ebsvalve_b;
  uint16_t cooling_pump;
  uint16_t lv_v;
} CurrentMeasurements;

void currentMonitor_init(ADC_HandleTypeDef* hadc1, ADC_HandleTypeDef* hadc2,
                         TIM_HandleTypeDef* trigtim);
uint8_t currentMonitor_checklimits();

#endif /* INC_CURRENT_MONITORING_H_ */
