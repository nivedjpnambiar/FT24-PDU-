/*
 * Channel_Control.h
 *
 *  Created on: 24. April, 2024
 *      Author: nived
 */

#ifndef INC_CHANNEL_CONTROL_H_
#define INC_CHANNEL_CONTROL_H_

#include "stm32f3xx_hal.h"

typedef union {
  struct {
    uint8_t NC : 1;
    uint8_t inverter : 1;
    uint8_t drs_buck : 1;
    uint8_t acu : 1;
    uint8_t reserved : 1;
    uint8_t lidar : 1;
    uint8_t sdc : 1;
    uint8_t alwayson : 1;
  };
  uint8_t porta;
} gpio_port_a;

typedef union {
  struct {
    uint8_t epsc: 1;
    uint8_t hyd_pump : 1;
    uint8_t NC : 1;       
    uint8_t ebs_cs : 1;
    uint8_t ebs_b : 1;
    uint8_t ebs_a : 1;
    uint8_t drs_profet : 1;
    uint8_t misc : 1;
  };
  uint8_t portb;
} gpio_port_b;

typedef union {
  struct {
    gpio_port_a porta;
    gpio_port_b portb;
  };
  uint16_t gpios_bitmask;

} PortExtenderGPIO;

void ChannelControl_init(I2C_HandleTypeDef* hi2c, TIM_HandleTypeDef* timer3,
                         TIM_HandleTypeDef* timer2);
void ChannelControl_UpdateGPIOs(PortExtenderGPIO);

void ChannelControl_UpdatePWMs(
  uint8_t radiatorfans,
  uint8_t pwmpumps,
  uint8_t tsacfans,
  uint8_t pwmaggregat
);

#endif /* INC_CHANNEL_CONTROL_H_ */
