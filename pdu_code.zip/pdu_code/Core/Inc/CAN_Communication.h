/*
 * CAN_Communication.h
 *
 *  Created on: 24. April, 2024
 *      Author: nived
 */

#ifndef INC_CAN_COMMUNICATION_H_
#define INC_CAN_COMMUNICATION_H_

#include "Channel_Control.h"
#include "can-halal.h"
#include "Current_Monitoring.h"


#define RX_STATUS_HEARTBEAT 0xC7
#define RX_STATUS_MSG_ID  0xC8  // new addresses will be given ( 0x C8 , 0xC9 usw)
#define TX_STATUS_MSG_ID  0xC9
#define CUR_CHANNELS_1_ID 0xCA
#define CUR_CHANNELS_2_ID 0xCB
#define CUR_CHANNELS_3_ID 0xCC
#define CUR_CHANNELS_4_ID 0xCD
#define LV_SENS_ID 0xCE

typedef struct {
  PortExtenderGPIO iostatus;
  uint8_t radiatorfans;
  uint8_t tsacfans;
  uint8_t pwmaggregat;
  uint8_t cooling_pump;
  uint8_t checksum;
} rx_status_frame;

void can_init(CAN_HandleTypeDef* hcan);
void can_rxupdateFrame();
void can_sendloop();

#endif /* INC_CAN_COMMUNICATION_H_ */

/* Channel Control CAN Frame
 *
 * byte 0 GPIO Bank A
 * byte 1 GPIO Bank B
 * PWM Fans
 * PWM Aggregat
 * PWM Pumpen
 * Checksum
 * */

/* Channel Status CAN Frame
 *
 * byte 0 state GPIO Bank A
 * byte 1 state GPIO Bank B
 * PWM Fans
 * PWM Aggregat
 * PWM Pumpen
 * Xor of Checksum
 *
 */
