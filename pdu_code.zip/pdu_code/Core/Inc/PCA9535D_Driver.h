/*
 * PCA9535D_Driver.h
 *
 *  Created on: 24. April, 2024
 *      Author: nived
 */

#ifndef INC_PCA9535D_DRIVER_H_
#define INC_PCA9535D_DRIVER_H_

#include "main.h"

#define INPUT_REG_BASE_ADDRESS                    0U
#define OUTPUT_REG_BASE_ADDRESS                   2U
#define INPUT_POLARITY_INVERSION_REG_BASE_ADDRESS 4U
#define CONFIGURATION_REG_BASE_ADDRESS            6U

#define GPIO_DIR_OUTPUT              0U
#define GPIO_DIR_INPUT               1U
#define GPIO_INPUT_POLARITY_INVERTED 1U
#define GPIO_INPUT_POLARITY_NORMAL   1U

#define SET_ALL_GPIO_OUTPUT_MASK 0xFF

#define PC9535_PORTA 0x00
#define PC9535_PORTB 0x01

#define PCA_I2C_BASE_ADDRESS 0x40

void PCA9535_init(I2C_HandleTypeDef* hi2c, uint8_t subadr);

void PCA9535_setGPIOPinDirection(uint8_t Port, uint8_t pin, uint8_t state);
void PCA9535_setGPIOPinOutput(uint8_t Port, uint8_t pin, uint8_t state);
void PCA9535_invertGPIOPinPolarity(uint8_t Port, uint8_t pin, uint8_t state);
uint8_t PCA9535_readGPIOPinInput(uint8_t Port, uint8_t pin);

void PCA9535_setGPIOPortDirection(uint8_t Port, uint8_t bitmask);
void PCA9535_setGPIOPortOutput(uint8_t Port, uint8_t bitmask);
void PCA9535_invertGPIOPortPolarity(uint8_t Port, uint8_t bitmask);
uint8_t PCA9535_readGPIOPortInput(uint8_t Port);

#endif /* INC_PCA9535D_DRIVER_H_ */
